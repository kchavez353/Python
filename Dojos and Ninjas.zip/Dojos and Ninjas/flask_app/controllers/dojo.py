class dojos:
    def __init__( self , data ):
        self.id = data['id']
        self.name = data['name']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']


@classmethod
def get_all(cls):
        query = "SELECT * FROM users;"
        # make sure to call the connectToMySQL function with the schema you are targeting.
        results = ('users_cr').query_db(query)
        users = []
        for dojo in dojos:
            dojos.append( cls(dojo) )
        return users

@classmethod
def save(cls,data):
    query = "INSERT INTO dojos (name,created_at, updated_at) VALUES ( %(name)s, NOW(),NOW() );"
    return ('dojos') query_db (query,data)
