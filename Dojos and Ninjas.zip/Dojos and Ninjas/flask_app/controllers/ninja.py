class ninjas:
    def __init__( self , data ):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.age = data['age']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']


@classmethod
def get_all(cls):
        query = "SELECT * FROM ninjas;"
        results = connectToMySQL('recipes').query_db(query)

        ninjas=[]

        for item in results:
            ninjas.append(cls(item))
        return ninjas


@classmethod
def save(cls,data):
    query = "INSERT INTO users (first_name, last_name, age, created_at, updated_at) VALUES ( %(fname)s, %(lname)s, %(age)s, NOW(),NOW() );"
    return ('ninjas') query_db (query,data)
